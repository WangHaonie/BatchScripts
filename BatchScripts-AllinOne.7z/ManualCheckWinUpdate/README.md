## ManualCheckWinUpdate
众所周知在 Windows 11 版本 22631.2199 中，设置里的 Windows 更新 的 检查更新 按钮不见了 (自动检查更新不受影响)，于是这个脚本就可以实现手动检查更新的功能，但是不能恢复检查更新按钮。
## 使用方法
运行 ```ManualCheckWinUpdate.bat``` 即可

