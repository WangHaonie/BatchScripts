## XyybsDownloader
该脚本可以根据输入的资源码从学英语报社官网下载听力文件
## 使用方法
1. 到 [JsonParser](https://github.com/WangHaonie/BatchScripts/tree/main/JsonParser) 下载 ```jsonParser.ps1```
2. 下载 ```xyybs.bat``` 和 ```XyybsDownloader.ps1``` 并将这3个文件放到同一目录，然后运行 ```xyybs.bat``` 按照提示即可