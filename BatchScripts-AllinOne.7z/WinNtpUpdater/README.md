## WinNtpUpdater
该工具可以解决 Windows 系统时间无法同步或不会同步的情况
## 主要功能
1. 系统默认 NTP 服务器将设置为 ```ntp1.aliyun.com```
2. 将 Windows Time 服务设置为自动启动
## 使用方法
1. 下载 ```WinNtpUpdater.bat``` 运行即可