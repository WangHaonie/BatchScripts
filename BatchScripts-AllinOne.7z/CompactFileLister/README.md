## CompactFileLister
查看磁盘中哪些文件夹被压缩 (Compact) 存储。要运行请下载 ```CompactFileLister.bat``` 和 ```CompactFileLister.ps1``` 到同一个文件夹
## 用法
直接运行 ```CompactFileLister.bat``` 按照提示即可。
