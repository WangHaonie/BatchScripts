## AdminChecker
检查当前账户是否具有管理员权限的 Batch 脚本。
## v1.0 (admin.bat)
主要调用 PowerShell 判断是否具有管理员权限，运行后显示  ```Yes``` 则有管理员权限，显示 ```No``` 则没有。
## v2.1 (admin2.1.bat)
可以判断当前用户是否为内置管理员、是否在 Administrators 组、是否具有管理员权限，更简洁直观。
